package com.huawei.opensdk.ec_sdk_demo.module.headphoto;


public class BitmapProperty
{
    static int devide = 1;
    float x;
    float y;
    float width;
    float height;
    int index = -1;

    @Override
    public String toString()
    {
        return "MyBitmap [x=" + x + ", y=" + y + ", width=" + width
                + ", height=" + height + ", devide=" + devide + ", index="
                + index + "]";
    }
}

