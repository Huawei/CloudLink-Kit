package com.huawei.opensdk.ec_sdk_demo.logic.contact.mvp;

import com.huawei.opensdk.ec_sdk_demo.logic.BaseView;


public interface IContactRecordContract
{
    interface IContactRecordView extends BaseView
    {

    }

    interface IContactRecordPresenter
    {
    }
}
