package com.huawei.opensdk.ec_sdk_demo.ui.contact;

import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.huawei.opensdk.ec_sdk_demo.R;
import com.huawei.opensdk.ec_sdk_demo.adapter.TeamAdapter;
import com.huawei.opensdk.ec_sdk_demo.common.UIConstants;
import com.huawei.opensdk.ec_sdk_demo.ui.base.BaseActivity;
import com.huawei.opensdk.imservice.ImContactGroupInfo;
import com.huawei.opensdk.imservice.ImMgr;

import java.util.List;

/**
 * This class is about contacts teams list activity.
 */
public class TeamsActivity extends BaseActivity implements AdapterView.OnItemClickListener {

    private TextView tvTitle;
    private ImageView ivIsChecked;
    private ListView listView;
    private TeamAdapter teamAdapter;

    private List<ImContactGroupInfo> contactGroupInfoList;
    private long checkGroupId = -1;
    private int allContactNum = 0;

    @Override
    public void initializeComposition() {
        setContentView(R.layout.teams);
        tvTitle = (TextView) findViewById(R.id.title_text);
        listView = (ListView) findViewById(R.id.team_list);

        tvTitle.setText(getString(R.string.team_check));

        View headView = getLayoutInflater().inflate(R.layout.team_item, null);
        TextView tvAllContacts = (TextView) headView.findViewById(R.id.team_name);
        TextView tvAllCount = (TextView) headView.findViewById(R.id.members_count);
        ivIsChecked = (ImageView) headView.findViewById(R.id.team_type_img);

        tvAllContacts.setText(getString(R.string.contact));
        tvAllCount.setText("(" + allContactNum + ")");
        ivIsChecked.setImageResource(R.drawable.search_member_team);
        if (-1 == checkGroupId)
        {
            ivIsChecked.setVisibility(View.VISIBLE);
        }
        else
        {
            ivIsChecked.setVisibility(View.GONE);
        }
        listView.addHeaderView(headView);
        teamAdapter.setDate(contactGroupInfoList);
        listView.setAdapter(teamAdapter);
        listView.setOnItemClickListener(this);
    }

    @Override
    public void initializeData() {
        teamAdapter = new TeamAdapter(this);
        Intent intent = getIntent();
        allContactNum = intent.getIntExtra(UIConstants.IM_ALL_CONTACT_NUM, 0);
        checkGroupId = intent.getLongExtra(UIConstants.IM_CHECK_CONTACT_GROUP_NAME, -1);
        contactGroupInfoList = ImMgr.getInstance().getAllContactGroupList();
        if (null == contactGroupInfoList || 0 == contactGroupInfoList.size())
        {
            return;
        }
        for (ImContactGroupInfo contactGroupInfo : contactGroupInfoList)
        {
            if (checkGroupId == contactGroupInfo.getGroupId())
            {
                teamAdapter.setCheckGroupId(checkGroupId);
            }
        }
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

        Intent intent = new Intent();
        if (0 == i)
        {
            intent.putExtra(UIConstants.IM_RETURN_CONTACT_GROUP_ALL, -1);
        }
        else
        {
            intent.putExtra(UIConstants.IM_RETURN_CONTACT_GROUP_ID, contactGroupInfoList.get(i - 1).getGroupId());
            intent.putExtra(UIConstants.IM_RETURN_CONTACT_GROUP_NAME, contactGroupInfoList.get(i - 1).getGroupName());
        }
        setResult(UIConstants.IM_RESULT_CODE_CONTACT_GROUP, intent);
        finish();
    }
}
