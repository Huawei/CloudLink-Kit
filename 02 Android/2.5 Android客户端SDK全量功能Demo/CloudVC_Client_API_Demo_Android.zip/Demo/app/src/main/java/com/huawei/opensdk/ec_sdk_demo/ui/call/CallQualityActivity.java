package com.huawei.opensdk.ec_sdk_demo.ui.call;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.huawei.ecterminalsdk.base.TsdkMediaQosInfo;
import com.huawei.opensdk.callmgr.CallInfo;
import com.huawei.opensdk.callmgr.CallMgr;
import com.huawei.opensdk.commonservice.localbroadcast.CustomBroadcastConstants;
import com.huawei.opensdk.commonservice.localbroadcast.LocBroadcast;
import com.huawei.opensdk.commonservice.localbroadcast.LocBroadcastReceiver;
import com.huawei.opensdk.commonservice.util.LogUtil;
import com.huawei.opensdk.demoservice.MeetingMgr;
import com.huawei.opensdk.ec_sdk_demo.R;
import com.huawei.opensdk.ec_sdk_demo.common.UIConstants;
import com.huawei.opensdk.ec_sdk_demo.ui.base.BaseActivity;

import java.util.Timer;
import java.util.TimerTask;

public class CallQualityActivity extends BaseActivity implements LocBroadcastReceiver {

    private int mCallID;
    private TsdkMediaQosInfo mQosInfo = null;
    private String[] mActions = new String[]{CustomBroadcastConstants.ACTION_CALL_CONNECTED,
            CustomBroadcastConstants.ACTION_CALL_END};

    private ImageView mLeaveIV;

    //音频质量
    private TextView textView2_2;
    private TextView textView2_3;
    private TextView textView2_4;
    private TextView textView2_5;
    private TextView textView2_6;

    private TextView textView3_2;
    private TextView textView3_3;
    private TextView textView3_4;
    private TextView textView3_5;
    private TextView textView3_6;

    //发送视频质量
    private TextView textView2_2_2;
    private TextView textView2_2_3;
    private TextView textView2_2_4;
    private TextView textView2_2_5;
    private TextView textView2_2_6;
    private TextView textView2_2_7;
    private TextView textView2_2_8;

    //接收视频质量
    private TextView textView3_2_2;
    private TextView textView3_2_3;
    private TextView textView3_2_4;
    private TextView textView3_2_5;
    private TextView textView3_2_6;
    private TextView textView3_2_7;
    private TextView textView3_2_8;

    @Override
    public void initializeComposition() {
        setContentView(R.layout.activity_call_quality);
        mLeaveIV = (ImageView) findViewById(R.id.leave_iv);
        textView2_2 = (TextView) findViewById(R.id.textView2_2);
        textView2_3 = (TextView) findViewById(R.id.textView2_3);
        textView2_4 = (TextView) findViewById(R.id.textView2_4);
        textView2_5 = (TextView) findViewById(R.id.textView2_5);
        textView2_6 = (TextView) findViewById(R.id.textView2_6);

        textView3_2 = (TextView) findViewById(R.id.textView3_2);
        textView3_3 = (TextView) findViewById(R.id.textView3_3);
        textView3_4 = (TextView) findViewById(R.id.textView3_4);
        textView3_5 = (TextView) findViewById(R.id.textView3_5);
        textView3_6 = (TextView) findViewById(R.id.textView3_6);

        textView2_2_2 = (TextView) findViewById(R.id.textView2_2_2);
        textView2_2_3 = (TextView) findViewById(R.id.textView2_2_3);
        textView2_2_4 = (TextView) findViewById(R.id.textView2_2_4);
        textView2_2_5 = (TextView) findViewById(R.id.textView2_2_5);
        textView2_2_6 = (TextView) findViewById(R.id.textView2_2_6);
        textView2_2_7 = (TextView) findViewById(R.id.textView2_2_7);
        textView2_2_8 = (TextView) findViewById(R.id.textView2_2_8);

        textView3_2_2 = (TextView) findViewById(R.id.textView3_2_2);
        textView3_2_3 = (TextView) findViewById(R.id.textView3_2_3);
        textView3_2_4 = (TextView) findViewById(R.id.textView3_2_4);
        textView3_2_5 = (TextView) findViewById(R.id.textView3_2_5);
        textView3_2_6 = (TextView) findViewById(R.id.textView3_2_6);
        textView3_2_7 = (TextView) findViewById(R.id.textView3_2_7);
        textView3_2_8 = (TextView) findViewById(R.id.textView3_2_8);

        mLeaveIV.setOnClickListener(onback);

//        Timer timer = new Timer(true);
//        TimerTask task = new TimerTask() {
//            @Override
//            public void run() {
//                mQosInfo = CallMgr.getInstance().getCallQuality(mCallID);
//                if (null != mQosInfo)
//                {
//                    setNetData();
//                }
//            }
//        };
//        //从现在起，5分钟调用一次
//        timer.schedule(task,0,300000);
    }

    @Override
    public void initializeData() {
        mCallID = CallMgr.getInstance().getCallId();

        if (0 == mCallID)
        {
            mCallID = MeetingMgr.getInstance().getCurrentConferenceCallID();
            if (0 == mCallID)
            {
                LogUtil.e(UIConstants.DEMO_TAG,"CallId is null");
                return;
            }
            mQosInfo = CallMgr.getInstance().getCallQuality(mCallID);
        }
        else
        {
            mQosInfo = CallMgr.getInstance().getCallQuality(mCallID);
            if (null == mQosInfo)
            {
                mCallID = MeetingMgr.getInstance().getCurrentConferenceCallID();
                mQosInfo = CallMgr.getInstance().getCallQuality(mCallID);

                if (null == mQosInfo) {
                    LogUtil.i(UIConstants.DEMO_TAG,"mQosInfo is null");
                    return;
                }
            }
        }

//        if(null != mConfID)
//        {
//            mQosInfo = CallMgr.getInstance().getCallQuality(Integer.parseInt(mConfID));
//        }
        LogUtil.i(UIConstants.DEMO_TAG,"mQosInfo is:"+mQosInfo.getRtTxAudio()+" "+mQosInfo.getRtTxMainVideo()
        + " mQosInfo.getRtTxAuxVideo()" +mQosInfo.getRtTxAuxVideo()+ " mQosInfo.getRtTxAuxVideo()"+mQosInfo.getRtTxAuxVideo());

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        handler.postDelayed(runnable, 1000);
    }

    @Override
    protected void onResume() {
        super.onResume();
        LocBroadcast.getInstance().registerBroadcast(this, mActions);
//        if ("".equals(mCallID) || 0 !=mCallID)
//        {
//            CallMgr.getInstance().getCallQuality(mCallID);
//        }
        setNetData();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(runnable);
        super.onDestroy();
        LocBroadcast.getInstance().unRegisterBroadcast(this, mActions);
    }
    public void setNetData()
    {
        if (null == mQosInfo)
        {
            return;
        }

        textView2_2.setText(String.valueOf(mQosInfo.getRtTxAudio().getProtocol()));
        textView2_3.setText(String.valueOf(mQosInfo.getRtTxAudio().getBitRate()));
        textView2_4.setText(String.valueOf(mQosInfo.getRtTxAudio().getLostPer()));
        textView2_5.setText(String.valueOf(mQosInfo.getRtTxAudio().getDelay()));
        textView2_6.setText(String.valueOf(mQosInfo.getRtTxAudio().getJitter()));

        textView3_2.setText(String.valueOf(mQosInfo.getRtRxAudio().getProtocol()));
        textView3_3.setText(String.valueOf(mQosInfo.getRtRxAudio().getBitRate()));
        textView3_4.setText(String.valueOf(mQosInfo.getRtRxAudio().getLostPer()));
        textView3_5.setText(String.valueOf(mQosInfo.getRtRxAudio().getDelay()));
        textView3_6.setText(String.valueOf(mQosInfo.getRtRxAudio().getJitter()));

        textView2_2_2.setText(String.valueOf(mQosInfo.getRtTxMainVideo().getProtocol()));
        textView2_2_3.setText(String.valueOf(mQosInfo.getRtTxMainVideo().getBitRate()));
        textView2_2_4.setText(String.valueOf(mQosInfo.getRtTxMainVideo().getFrameRate()));
        textView2_2_5.setText(String.valueOf(mQosInfo.getRtTxMainVideo().getH264Profile()));
        textView2_2_6.setText(String.valueOf(mQosInfo.getRtTxMainVideo().getLostPer()));
        textView2_2_7.setText(String.valueOf(mQosInfo.getRtTxMainVideo().getDelay()));
        textView2_2_8.setText(String.valueOf(mQosInfo.getRtTxMainVideo().getJitter()));

        textView3_2_2.setText(String.valueOf(mQosInfo.getRtTxMainVideo().getProtocol()));
        textView3_2_3.setText(String.valueOf(mQosInfo.getRtTxMainVideo().getBitRate()));
        textView3_2_4.setText(String.valueOf(mQosInfo.getRtTxMainVideo().getFrameRate()));
        textView3_2_5.setText(String.valueOf(mQosInfo.getRtTxMainVideo().getH264Profile()));
        textView3_2_6.setText(String.valueOf(mQosInfo.getRtTxMainVideo().getLostPer()));
        textView3_2_7.setText(String.valueOf(mQosInfo.getRtTxMainVideo().getDelay()));
        textView3_2_8.setText(String.valueOf(mQosInfo.getRtTxMainVideo().getJitter()));

    }

    @Override
    public void onReceive(String broadcastName, Object obj) {
        switch (broadcastName)
        {
            case CustomBroadcastConstants.ACTION_CALL_CONNECTED:
                if (obj instanceof CallInfo) {
                    CallInfo callInfo = (CallInfo)obj;
                    mCallID = callInfo.getCallID();
                }
            case CustomBroadcastConstants.ACTION_CALL_END:
                runOnUiThread(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        finish();
                    }
                });
                break;

            default:
                break;
        }
    }

    private View.OnClickListener onback = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId())
            {
                case R.id.leave_iv:
                    CallQualityActivity.super.onBack();
                    break;
                default:
                    break;
            }
        }
    };

    private Handler handler = new Handler();
    private Runnable runnable = new Runnable() {
        @Override
        public void run() {
            mQosInfo = CallMgr.getInstance().getCallQuality(mCallID);
            if (null != mQosInfo)
            {
                setNetData();
            }
            handler.postDelayed(this, 1000);
        }
    };
}
