package com.huawei.opensdk.ec_sdk_demo.logic.contact.mvp;

//import com.huawei.contacts.PersonalContact;

public interface ISingleChatContract
{
    interface ISingleChatView
    {

    }

    interface ISingleChatPresenter
    {
//        void addMember(PersonalContact personalContact);

        void clearHistory();
    }
}
