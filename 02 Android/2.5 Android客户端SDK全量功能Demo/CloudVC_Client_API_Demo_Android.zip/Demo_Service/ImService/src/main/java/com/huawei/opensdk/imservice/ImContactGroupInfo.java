package com.huawei.opensdk.imservice;

import java.util.List;

public class ImContactGroupInfo {

    private long groupId;
    private String groupName;
    private int groupMember;
    private List<ImContactInfo> list;

    public long getGroupId() {
        return groupId;
    }

    public void setGroupId(long groupId) {
        this.groupId = groupId;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public int getGroupMember() {
        return groupMember;
    }

    public void setGroupMember(int groupMember) {
        this.groupMember = groupMember;
    }

    public List<ImContactInfo> getList() {
        return list;
    }

    public void setList(List<ImContactInfo> list) {
        this.list = list;
    }
}
