package com.huawei.opensdk.imservice;

import android.util.Log;

import com.huawei.ecterminalsdk.base.TsdkBeAddedToChatGroupInfo;
import com.huawei.ecterminalsdk.base.TsdkChatGroupInfo;
import com.huawei.ecterminalsdk.base.TsdkChatGroupInfoUpdateType;
import com.huawei.ecterminalsdk.base.TsdkChatGroupMemberGetResult;
import com.huawei.ecterminalsdk.base.TsdkChatGroupModifyOpType;
import com.huawei.ecterminalsdk.base.TsdkChatGroupQueryParam;
import com.huawei.ecterminalsdk.base.TsdkChatGroupQueryResult;
import com.huawei.ecterminalsdk.base.TsdkChatGroupQueryType;
import com.huawei.ecterminalsdk.base.TsdkChatGroupType;
import com.huawei.ecterminalsdk.base.TsdkChatGroupUpdateInfo;
import com.huawei.ecterminalsdk.base.TsdkContactAndChatGroupsInfo;
import com.huawei.ecterminalsdk.base.TsdkGetContactAndChatGroupsReqParam;
import com.huawei.ecterminalsdk.base.TsdkImUserInfo;
import com.huawei.ecterminalsdk.base.TsdkImUserStatus;
import com.huawei.ecterminalsdk.base.TsdkImUserStatusInfo;
import com.huawei.ecterminalsdk.base.TsdkLeaveChatGroupResult;
import com.huawei.ecterminalsdk.base.TsdkRspJoinChatGroupMsg;
import com.huawei.ecterminalsdk.base.TsdkSelfDefContactInfo;
import com.huawei.ecterminalsdk.models.im.TsdkChatGroup;
import com.huawei.ecterminalsdk.models.im.TsdkContactGroup;
import com.huawei.ecterminalsdk.models.im.TsdkImManager;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is about instant messaging function management class.
 * Im模块管理类
 */
public class ImMgr implements IImMgr
{
    private static final String TAG = ImMgr.class.getSimpleName();

    /**
     * The user info.
     * 用户自己的信息
     */
//    private PersonalContact mSelfContact;

    /**
     * Instance object of im component.
     * 获取一个ImMgr对象
     */
    private static final ImMgr mInstance = new ImMgr();

    /**
     * Self account info.
     * 用户自己的账号信息
     */
    private ImAccountInfo imAccountInfo;

    /**
     * Initial state of the user:away state.
     * 离线AWAY = 0，在线ON_LINE = 1，繁忙BUSY = 3，离开XA = 4，请勿打扰DND = 5
     */
    private ImConstant.ImStatus mImLoginStatus = ImConstant.ImStatus.AWAY;

    /**
     * The TsdkImManager function object.
     * TsdkImManager对象
     */
    private TsdkImManager tsdkImManager;

    /**
     * 当前聊天群组操作对象
     */
    private TsdkChatGroup currentChatGroup;

    private TsdkChatGroupInfo tsdkChatGroupInfo;

    /**
     * ImChatGroupInfo对象
     */
    private ImChatGroupInfo chatGroupInfo;

    /**
     *  UI notification.
     *  回调接口对象
     */
    private IImNotification mNotification;

    /**
     * The user account.
     * 账号
     */
    private String mMyAccount;

    /**
     * A map collection of message ID and message content.
     * 已读消息，消息id和消息体的map集合
     */
//    private Map<String, InstantMessage> mUnMarkReadMessageMap = new ConcurrentHashMap<>();

    /**
     * Record saved path.
     * 录音的保存路径
     */
    private String mRecordPath;

    /**
     * Contact list (friend + defined contact).
     * 联系人列表(好友 + 自定义联系人)
     */
    private List<ImContactInfo> imContactInfoList = new ArrayList<>();

    private List<ImContactGroupInfo> imContactGroupInfoList = new ArrayList<>();

    /**
     * Chat group information list.
     * 聊天群组信息列表
     */
    private List<ImChatGroupInfo> imChatGroupInfoList = new ArrayList<>();

    /**
     * This is a constructor of ImMgr class.
     * 构造方法
     */
    private ImMgr()
    {
        tsdkImManager = TsdkImManager.getObject();
        currentChatGroup = new TsdkChatGroup();
        tsdkChatGroupInfo = new TsdkChatGroupInfo();
        chatGroupInfo = new ImChatGroupInfo();
    }

    /**
     * This method is used to get instance object of ImMgr.
     * 获取ImMgr对象实例
     * @return ImMgr Return instance object of ImMgr
     *               返回一个ImMgr对象实例
     */
    public static ImMgr getInstance()
    {
        return mInstance;
    }

    /**
     * This method is used to register im module UI callback.
     * 注册回调
     */
    public void regImServiceNotification(IImNotification notification)
    {
        mNotification = notification;
    }

    public ImConstant.ImStatus getStatus()
    {
        return mImLoginStatus;
    }

    public void setImLoginStatus(ImConstant.ImStatus status)
    {
        this.mImLoginStatus = status;
    }

    /**
     * This method is used to get user information.
     * 获取指定用户信息
     * @param account  Indicates account
     *                 账号
     * @return ImContactInfo  Return the obtained user information object
     *                        返回获取到得用户信息对象
     */
    @Override
    public ImContactInfo getUserInfo(String account) {
        this.mMyAccount = account;
        TsdkImUserInfo imUserInfo = tsdkImManager.getUserInfo(account);
        ImContactInfo imContactInfo = new ImContactInfo();
        imContactInfo.setName(imUserInfo.getName());
        imContactInfo.setSignature(imUserInfo.getSignature());
        imContactInfo.setAccount(imUserInfo.getStaffAccount());
        imContactInfo.setAddress(imUserInfo.getAddress());
        imContactInfo.setDepartmentName(imUserInfo.getDepartmentNameEn());
        imContactInfo.setEmail(imUserInfo.getEmail());
        imContactInfo.setFax(imUserInfo.getFax());
        imContactInfo.setMobile(imUserInfo.getMobile());
        imContactInfo.setSoftNumber(imUserInfo.getVoip());
        imContactInfo.setTitle(imUserInfo.getTitle());
        imContactInfo.setZipCode(imUserInfo.getZipCode());
        return imContactInfo;
    }

    /**
     * This method is used to set user information.
     * 设置指定用户信息
     * @param contactInfo Indicates user information
     *                    用户信息
     * @return int Return execute result
     *             返回执行结果
     */
    @Override
    public int setUserInfo(ImContactInfo contactInfo) {
        Log.i(TAG,  "set user info");

        TsdkImUserInfo userInfo = new TsdkImUserInfo();
        userInfo.setStaffAccount(contactInfo.getAccount());
        userInfo.setSignature(contactInfo.getSignature());
        int result = tsdkImManager.setUserInfo(userInfo);
        if (0 != result)
        {
            Log.e(TAG, "setUserInfo result ->" + result);
        }
        return result;
    }

    /**
     * This method is used to set user states.
     * 设置用户自己的在线状态
     * @param status        Indicates user status
     *                      用户状态
     * @param statusDesc    Indicates status description
     *                      状态描述
     * @return int Return execute result
     *             返回执行结果
     */
    @Override
    public int setUserStatus(ImConstant.ImStatus status, String statusDesc) {
        TsdkImUserStatusInfo statusInfo = new TsdkImUserStatusInfo();
        TsdkImUserStatus userStatus = TsdkImUserStatus.TSDK_E_IM_USER_STATUS_INIT;
        switch (status)
        {
            case AWAY:
                userStatus = TsdkImUserStatus.TSDK_E_IM_USER_STATUS_OFFLINE;
                break;
            case ON_LINE:
                userStatus = TsdkImUserStatus.TSDK_E_IM_USER_STATUS_ONLINE;
                break;
            case BUSY:
                userStatus = TsdkImUserStatus.TSDK_E_IM_USER_STATUS_BUSY;
                break;
            case XA:
                userStatus = TsdkImUserStatus.TSDK_E_IM_USER_STATUS_LEAVE;
                break;
            case DND:
                userStatus = TsdkImUserStatus.TSDK_E_IM_USER_STATUS_DND;
                break;
                default:
                    break;
        }
        statusInfo.setStatus(userStatus);
        statusInfo.setStatusDesc(statusDesc);
        int result = tsdkImManager.setPersonalStatus(statusInfo);
        if (0 != result)
        {
            Log.e(TAG, "setUserStatus result ->" + result);
        }
        else
        {
            setImLoginStatus(status);
        }
        return result;
    }

    /**
     * This method is used to get contact group and chat group lists.
     * 获取联系人分组和聊天群组列表
     * @param isSync         Indicates whether to synchronize in full
     *                       是否全量同步
     * @param timestamp      Indicates time stamp of incremental synchronization (year month day hour minute second)
     *                       增量同步时间戳，时间格式：19000000000000
     * @return TsdkContactAndChatGroupsInfo Return contact group and chat group lists object
     *                                      返回获取到得联系人和聊天列表对象
     */
    @Override
    public TsdkContactAndChatGroupsInfo getContactAndChatGroups(boolean isSync, String timestamp) {
        TsdkGetContactAndChatGroupsReqParam reqParam = new TsdkGetContactAndChatGroupsReqParam();
        reqParam.setIsSyncAll(isSync == true? 1 : 0);
        reqParam.setTimestamp(timestamp);
        TsdkContactAndChatGroupsInfo contactAndChatGroupsInfo = tsdkImManager.getContactAndChatGroups(reqParam);
        if (null == contactAndChatGroupsInfo)
        {
            return null;
        }
        return contactAndChatGroupsInfo;
    }

    /**
     * This method is used to get group objects by group id.
     * 通过分组id获取分组对象
     * @param groupId   Indicates group id
     *                  分组id
     * @return ImContactGroupInfo Return group object.
     *                            返回分组对象
     */
    @Override
    public ImContactGroupInfo getContactGroupByGroupId(long groupId) {
        TsdkContactGroup contactGroup = tsdkImManager.getContactGroupByGroupId(groupId);

        ImContactGroupInfo contactGroupInfo = new ImContactGroupInfo();
        contactGroupInfo.setGroupId(contactGroup.getGroupId());
        contactGroupInfo.setGroupName(contactGroup.getGroupName());

        List<ImContactInfo> contactInfoList = new ArrayList<>();
        if (null != contactGroup.getFriendList())
        {
            for (TsdkImUserInfo imUserInfo : contactGroup.getFriendList())
            {
                ImContactInfo contactInfo = new ImContactInfo();
                contactInfo.setContactType(1);
                contactInfo.setName(imUserInfo.getName());
                contactInfo.setSignature(imUserInfo.getSignature());
                contactInfoList.add(contactInfo);
            }
        }
        if (null != contactGroup.getContactList())
        {
            for (TsdkSelfDefContactInfo selfDefContactInfo : contactGroup.getContactList())
            {
                ImContactInfo contactInfo = new ImContactInfo();
                contactInfo.setContactType(0);
                contactInfo.setName(selfDefContactInfo.getName());
                contactInfoList.add(contactInfo);
            }
        }
        contactGroupInfo.setList(contactInfoList);
        return contactGroupInfo;
    }

    /**
     * This method is used to get all the contacts of the user.
     * 获取用户的所有联系人(好友/自定义联系人)
     * @return List<ImContactInfo> Return contacts list
     *                             返回联系人列表
     */
    @Override
    public List<ImContactInfo> getAllContactList() {
        imContactInfoList.clear();
        if (null != tsdkImManager.getFriendList())
        {
            for (TsdkImUserInfo imUserInfo : tsdkImManager.getFriendList())
            {
                ImContactInfo contactInfo = new ImContactInfo();
                contactInfo.setContactType(1);
                contactInfo.setName(imUserInfo.getName());
                contactInfo.setSignature(imUserInfo.getSignature());
                imContactInfoList.add(contactInfo);
            }
        }
        if (null != tsdkImManager.getContactList())
        {
            for (TsdkSelfDefContactInfo selfDefContactInfo : tsdkImManager.getContactList())
            {
                ImContactInfo contactInfo = new ImContactInfo();
                contactInfo.setContactType(0);
                contactInfo.setName(selfDefContactInfo.getName());
                imContactInfoList.add(contactInfo);
            }
        }
        return imContactInfoList;
    }

    /**
     * 获取所有联系人分组
     * @return
     */
    @Override
    public List<ImContactGroupInfo> getAllContactGroupList() {
        imContactGroupInfoList.clear();
        if (0 != tsdkImManager.getContactGroupList().size())
        {
            for (TsdkContactGroup contactGroup : tsdkImManager.getContactGroupList())
            {
                ImContactGroupInfo imContactGroupInfo = new ImContactGroupInfo();
                int memberNumber = 0;
                imContactGroupInfo.setGroupId(contactGroup.getGroupId());
                imContactGroupInfo.setGroupName(contactGroup.getGroupName());
                if (null != contactGroup.getContactList())
                {
                    memberNumber = memberNumber + contactGroup.getContactList().size();
                }
                if (null != contactGroup.getFriendList())
                {
                    memberNumber = memberNumber + contactGroup.getFriendList().size();
                }
                imContactGroupInfo.setGroupMember(memberNumber);
                imContactGroupInfoList.add(imContactGroupInfo);
            }
        }
        return imContactGroupInfoList;
    }

    /**
     * 获取聊天分组
     * @return
     */
    @Override
    public List<ImChatGroupInfo> getAllChatGroupList() {
        imChatGroupInfoList.clear();
        if (0 != tsdkImManager.getChatGroupList().size())
        {
            for (TsdkChatGroup chatGroup : tsdkImManager.getChatGroupList())
            {
                chatGroupInfo = new ImChatGroupInfo();
                chatGroupInfo.setGroupId(chatGroup.getChatGroupInfo().getGroupId());
                chatGroupInfo.setGroupType(chatGroup.getChatGroupInfo().getGroupType());
                chatGroupInfo.setGroupName(chatGroup.getChatGroupInfo().getGroupName());
                imChatGroupInfoList.add(chatGroupInfo);
            }
        }
        return imChatGroupInfoList;
    }

    @Override
    public String addChatGroup(ImChatGroupInfo chatGroupInfo) {
        tsdkChatGroupInfo.setGroupName(chatGroupInfo.getGroupName());
        tsdkChatGroupInfo.setOwnerAccount(chatGroupInfo.getOwnerAccount());
        if (TsdkChatGroupType.TSDK_E_CHAT_GROUP_FIXED_GROUP.getIndex() == chatGroupInfo.getGroupType())
        {
            tsdkChatGroupInfo.setGroupType(TsdkChatGroupType.TSDK_E_CHAT_GROUP_FIXED_GROUP);
        }
        else
        {
            tsdkChatGroupInfo.setGroupType(TsdkChatGroupType.TSDK_E_CHAT_GROUP_DISCUSSION_GROUP);
        }
        String groupId = tsdkImManager.addChatGroup(tsdkChatGroupInfo);
        if (null == groupId)
        {
            Log.e(TAG, "addChatGroup failed");
        }
        return groupId;
    }

    @Override
    public int delChatGroup(String groupId, int type) {
        TsdkChatGroupType chatGroupType;
        if (type == TsdkChatGroupType.TSDK_E_CHAT_GROUP_DISCUSSION_GROUP.getIndex())
        {
            chatGroupType = TsdkChatGroupType.TSDK_E_CHAT_GROUP_DISCUSSION_GROUP;
        }
        else
        {
            chatGroupType = TsdkChatGroupType.TSDK_E_CHAT_GROUP_FIXED_GROUP;
        }
        int result = tsdkImManager.delChatGroup(groupId, chatGroupType);
        if (0 != result)
        {
            Log.e(TAG, "delChatGroup result ->" + result);
        }
        return result;
    }

    @Override
    public int modifyChatGroupInfo(ImChatGroupInfo imChatGroupInfo, int type) {
        if (null == currentChatGroup)
        {
            Log.e(TAG,  "modify chat group info, currentChatGroup is null ");
            return 0;
        }

        tsdkChatGroupInfo.setGroupId(imChatGroupInfo.getGroupId());
        tsdkChatGroupInfo.setOwnerAccount(imChatGroupInfo.getOwnerAccount());
        tsdkChatGroupInfo.setGroupName(imChatGroupInfo.getGroupName());
        tsdkChatGroupInfo.setManifesto(imChatGroupInfo.getManifesto());
        tsdkChatGroupInfo.setDescription(imChatGroupInfo.getDescription());
        if (ImConstant.DISCUSSION == imChatGroupInfo.getGroupType())
        {
            tsdkChatGroupInfo.setGroupType(TsdkChatGroupType.TSDK_E_CHAT_GROUP_DISCUSSION_GROUP);
        }
        else
        {
            tsdkChatGroupInfo.setGroupType(TsdkChatGroupType.TSDK_E_CHAT_GROUP_FIXED_GROUP);
        }

        TsdkChatGroupModifyOpType opType = TsdkChatGroupModifyOpType.TSDK_E_CHAT_GROUP_MODIFY_DEFAULT_PARAM;
        switch (type)
        {
            case ImConstant.GroupOpType.CHAT_GROUP_MODIFY_DEFAULT_PARAM:
                opType = TsdkChatGroupModifyOpType.TSDK_E_CHAT_GROUP_MODIFY_DEFAULT_PARAM;
                break;
            case ImConstant.GroupOpType.CHAT_GROUP_MODIFY_GROUP_TYPE:
                opType = TsdkChatGroupModifyOpType.TSDK_E_CHAT_GROUP_MODIFY_GROUP_TYPE;
                break;
                default:
                    break;
        }

        int result = currentChatGroup.modifyChatGroup(tsdkChatGroupInfo, opType);
        return result;
    }

    @Override
    public List<ImChatGroupInfo> queryChatGroup(String keyword) {
        TsdkChatGroupQueryParam queryParam = new TsdkChatGroupQueryParam();
        queryParam.setSearchKeyword(keyword);
        queryParam.setQueryType(TsdkChatGroupQueryType.TSDK_E_CHAT_GROUP_QUERY_BY_NAME_ID);
        queryParam.setIsNeedTotalCount(1);  // 是否需要返回总数
        queryParam.setMaxReturnedCount(20); // 本次查询最大返回结果数量
        TsdkChatGroupQueryResult queryResult = tsdkImManager.queryChatGroups(queryParam);
        if (null == queryResult)
        {
            Log.e(TAG, "queryChatGroup failed.");
            return null;
        }

        imChatGroupInfoList.clear();
        List<TsdkChatGroupInfo> chatGroupInfoList;
        if (queryResult.getChatGroupInfoList().size() > 0)
        {
            chatGroupInfoList = queryResult.getChatGroupInfoList();
            for (TsdkChatGroupInfo tsdkChatGroupInfo : chatGroupInfoList)
            {
                ImChatGroupInfo chatGroupInfo = new ImChatGroupInfo();
                chatGroupInfo.setGroupId(tsdkChatGroupInfo.getGroupId());
                chatGroupInfo.setGroupName(tsdkChatGroupInfo.getGroupName());
                chatGroupInfo.setGroupType(tsdkChatGroupInfo.getGroupType());
                imChatGroupInfoList.add(chatGroupInfo);
            }
        }
        return imChatGroupInfoList;
    }

    @Override
    public ImChatGroupInfo getChatGroupInfo(String groupId) {
        this.currentChatGroup = tsdkImManager.getChatGroupByGroupId(groupId);

        if (null == currentChatGroup)
        {
            Log.e(TAG,  "get chat group info, currentChatGroup is null ");
            return null;
        }
        tsdkChatGroupInfo = tsdkImManager.getChatGroupDetail(groupId);

        if (null == tsdkChatGroupInfo)
        {
            Log.e(TAG, "getChatGroupInfo failed.");
            return null;
        }

        chatGroupInfo.setGroupId(tsdkChatGroupInfo.getGroupId());
        chatGroupInfo.setGroupName(tsdkChatGroupInfo.getGroupName());
        chatGroupInfo.setManifesto(tsdkChatGroupInfo.getManifesto());
        chatGroupInfo.setDescription(tsdkChatGroupInfo.getDescription());
        chatGroupInfo.setGroupType(tsdkChatGroupInfo.getGroupType());
        chatGroupInfo.setOwnerAccount(tsdkChatGroupInfo.getOwnerAccount());
        return chatGroupInfo;
    }

    @Override
    public List<ImContactInfo> getChatGroupMembers(String timestamp, boolean isSyncAll) {
        if (null == currentChatGroup)
        {
            Log.e(TAG,  "get chat group members, currentChatGroup is null ");
            return null;
        }

        // 获取聊天群组成员之前先清空上一次成员列表
        imContactInfoList.clear();
        TsdkChatGroupMemberGetResult result = currentChatGroup.getChatGroupMembers(timestamp, isSyncAll);
        if (result.getMemberList().isEmpty())
        {
            return null;
        }
        for (TsdkImUserInfo userInfo : result.getMemberList())
        {
            ImContactInfo contactInfo = new ImContactInfo();
            contactInfo.setAccount(userInfo.getStaffAccount());
            imContactInfoList.add(contactInfo);
        }
        return imContactInfoList;
    }

    @Override
    public int addChatGroupMember(boolean isInvite, String inviteAccount, String joiningAccount) {
        if (null == currentChatGroup)
        {
            Log.e(TAG,  "add chat group member, currentChatGroup is null ");
            return 0;
        }

        /**
         * 通过id获取tsdkChatGroup对象的，但是由于这个方法中获取的对象只在全量更新的时候才能得到，目前实现方式如下：
         * 第一次创建聊天群组成功后，添加群组成员：tsdkChatGroup对象从创建群组的回调中获取
         * 查询已经创建的聊天群组，添加群组成员：tsdkChatGroup对象从查询结果中获取
         */
        int result = currentChatGroup.requestJoinChatGroup(isInvite, inviteAccount , "", joiningAccount);
        if (0 != result)
        {
            Log.e(TAG, "addChatGroupMember result ->" + result);
        }
        return result;
    }

    @Override
    public int delChatGroupMember(String memberAccount) {
        if (null == currentChatGroup)
        {
            Log.e(TAG,  "del chat group member, currentChatGroup is null ");
            return 0;
        }

        int result = currentChatGroup.delChatGroupMember(memberAccount);
        if (0 != result)
        {
            Log.e(TAG, "delChatGroupMember result ->" + result);
        }
        return result;
    }

    @Override
    public int leaveChatGroup() {
        if (null == currentChatGroup)
        {
            Log.e(TAG,  "leave chat group, currentChatGroup is null ");
            return 0;
        }

        int result = currentChatGroup.leaveChatGroup();
        if (0 != result)
        {
            Log.e(TAG, "leaveChatGroup result ->" + result);
        }
        return result;
    }

    public void updateChatGroupInfo(TsdkChatGroup chatGroup)
    {
        chatGroupInfo.setGroupId(chatGroup.getChatGroupInfo().getGroupId());
        chatGroupInfo.setGroupName(chatGroup.getChatGroupInfo().getGroupName());
        chatGroupInfo.setManifesto(chatGroup.getChatGroupInfo().getManifesto());
        chatGroupInfo.setDescription(chatGroup.getChatGroupInfo().getDescription());
        chatGroupInfo.setGroupType(chatGroup.getChatGroupInfo().getGroupType());
        chatGroupInfo.setOwnerAccount(chatGroup.getChatGroupInfo().getOwnerAccount());
    }

    /**
     * This method is used to logout.
     * 登出(注销)
     */
    public void imLogout()
    {
        //将个人状态设置为离线
        setImLoginStatus(ImConstant.ImStatus.AWAY);
        //Clear unread message map.
        //清除未读消息的map集合
        UnreadMessageService.getInstance().clearUnreadMap();

//        TupIm.instance().clearResources();
    }

    /*********************************************************************************************************************/

    /**
     * [en]This method is used to handle user update information event.
     * [cn]处理用户更新信息事件
     *
     * @param userInfoList            [en]Indicates user information list
     *                                [cn]更新用户的列表
     */
    public void handleUserInfoUpdate(List<TsdkImUserInfo> userInfoList)
    {
        if (null != userInfoList)
        {
            List<ImContactInfo> contactInfoList = new ArrayList<>();
            for (TsdkImUserInfo imUserInfo : userInfoList)
            {
                ImContactInfo imContactInfo = new ImContactInfo();
                imContactInfo.setName(imUserInfo.getName());
                imContactInfo.setSignature(imUserInfo.getSignature());
                imContactInfo.setAccount(imUserInfo.getStaffAccount());
                imContactInfo.setAddress(imUserInfo.getAddress());
                imContactInfo.setDepartmentName(imUserInfo.getDepartmentNameEn());
                imContactInfo.setEmail(imUserInfo.getEmail());
                imContactInfo.setFax(imUserInfo.getFax());
                imContactInfo.setMobile(imUserInfo.getMobile());
                imContactInfo.setSoftNumber(imUserInfo.getVoip());
                imContactInfo.setTitle(imUserInfo.getTitle());
                imContactInfo.setZipCode(imUserInfo.getZipCode());
                contactInfoList.add(imContactInfo);
            }
            mNotification.onUserInfoUpdate(contactInfoList);
        }
        else
        {
            mNotification.onUserInfoUpdate(null);
        }
    }

    public void handleJoinChatGroupRsp(TsdkChatGroup chatGroup, TsdkRspJoinChatGroupMsg rspJoinChatGroupMsg)
    {
        Log.i(TAG, "handleJoinChatGroupRsp.");
        if (null == chatGroup || null == rspJoinChatGroupMsg)
        {
            return;
        }

    }

    public void handleJoinChatGroupInd(TsdkChatGroup chatGroup, TsdkBeAddedToChatGroupInfo beAddedToChatGroupInfo)
    {
        Log.i(TAG, "handleJoinChatGroupInd.");
        if (null == chatGroup || null == beAddedToChatGroupInfo)
        {
            return;
        }
        this.currentChatGroup = chatGroup;
        mNotification.onJoinChatGroupInd(chatGroup);
    }

    public void handleLeaveChatGroupResult(TsdkLeaveChatGroupResult leaveChatGroupResult)
    {
        Log.i(TAG, "handleLeaveChatGroupResult.");
        if (null == leaveChatGroupResult)
        {
            return;
        }

        mNotification.onLeaveChatGroupResult(leaveChatGroupResult.getResult());
    }

    public void handleChatGroupInfoUpdate(TsdkChatGroup chatGroup, TsdkChatGroupUpdateInfo chatGroupUpdateInfo, TsdkChatGroupInfoUpdateType updateType)
    {
        Log.i(TAG, "handleChatGroupInfoUpdate.");
        if (null == chatGroupUpdateInfo)
        {
            return;
        }

        if (null != chatGroup)
        {
            updateChatGroupInfo(chatGroup);
        }

        int type = ImConstant.ChatGroupUpdateType.CHAT_GROUP_INFO_UPDATE;
        switch (updateType)
        {
            case TSDK_E_CHAT_GROUP_DEFAULT_INFO_UPDATE:
                type = ImConstant.ChatGroupUpdateType.CHAT_GROUP_INFO_UPDATE;
                break;
            case TSDK_E_CHAT_GROUP_ADD_MEMBER:
                type = ImConstant.ChatGroupUpdateType.CHAT_GROUP_ADD_MEMBER;
                break;
            case TSDK_E_CHAT_GROUP_DEL_MEMBER:
                type = ImConstant.ChatGroupUpdateType.CHAT_GROUP_DEL_MEMBER;
                if (chatGroupUpdateInfo.getUpdateMemberAccount().equals(mMyAccount))
                {
                    // 如果被删除的成员是自己的话，则删掉本地群组，此时需要增量更新才能删除掉该聊天分组
                    type = ImConstant.ChatGroupUpdateType.CHAT_GROUP_DISMISS;
                }
                break;
            case TSDK_E_CHAT_GROUP_OWNER_UPDATE:
                type = ImConstant.ChatGroupUpdateType.CHAT_GROUP_OWNER_UPDATE;
                break;
            case TSDK_E_CHAT_GROUP_DISMISS:
                type = ImConstant.ChatGroupUpdateType.CHAT_GROUP_DISMISS;
                break;
                default:
                    break;
        }

        mNotification.onChatGroupInfoUpdate(chatGroupInfo, type);
    }

}
