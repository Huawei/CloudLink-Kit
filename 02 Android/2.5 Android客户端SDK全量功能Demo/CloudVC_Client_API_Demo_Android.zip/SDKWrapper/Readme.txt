从网站上下载的android SDK包下载解压并拷贝到此目录
--SDKWrapper
 |-libs
 |-src
 |-build.gradle
 |-Readme.txt
 |-SdkCopy.bat