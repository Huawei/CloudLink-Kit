module.exports = {
    "CONVERSATION": "消息",
    "RECENT_CONTACTS": "最近联系人",
    "NOTIFICATION_BAR_UNREAD": "[{0}条]",
    "COMMON_DELETE": "删除",
    "MULTIDEVICE_PC_LOGINED": "PC客户端已登录",
    "BUTTON_ADD": "添加",
    "RECENT_DELETE_CHECK_FILE_TRANSFER": " 正在传输文件，删除对话会中断传输，确定删除？ ",
    "CONTACT_HAS_NO_USERNAME": "联系人没有用户名",
    "EVERY_ADVANCE_FROM_COMMUNICATION": "一天的工作，从沟通开始",
    "DRAG_FILE_PROMPT": "拖动到这里发送给 {0}",
    "RECENT_INFO_MEMBER_TITLE": "成员",
    "RECENT_INFO_IMG_AND_VIDEO_TITLE": "图片和视频",
    "RECENT_INFO_ANNOUNCEMENT_TITLE": "团队公告",
    "RECENT_INFO_GROUP_MEMBER_TITLE": "团队成员",
    "CLOUD_SPACE": "云空间",
    "YOU_HAVE_DISSOLVED_OR_LEFT_THE_GROUP": "您已解散或退出该团队"
}