"use strict";
(function(root) {
    var configParam = {
        logParam: "",
        tlsParam: "",
        proxyParam: "",
        serviceSecurityParam: "",
        iptServiceConfigParam: "",
        localAddress: "",
        filePathInfo: "",
        dpiInfo: "",
        networkInfo: "",
        ipCallSwitch:0,
        confCtrlParam:"",
        sendDataSwitch:"",
        baseInfoParam:"",
        frameParam:"",
        visibleInfo:""
    }
    var callback = function(){}
    tsdkClient.setConfigParam(configParam, callback);
})(this);