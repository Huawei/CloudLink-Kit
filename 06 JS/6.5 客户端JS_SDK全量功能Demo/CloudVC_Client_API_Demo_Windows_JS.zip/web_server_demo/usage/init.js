"use strict";
(function(root) {
    var tsdkAppInfoParam = {
        "clientType": 0,
        "productName": "SoftClient on Desktop",
        "deviceSn": "1",
        "supportAudioAndVideoCall": 1,
        "supportAudioAndVideoConf": 1,
        "supportDataConf": 1,
        "supportCtd": 0,
        "supportIm": 0,
        "supportRichMediaMessage": 0,
        "supportEnterpriseAddressBook": 0,
        "useUiPlugin": 1,
        "isWsInvokeMode": 1,
    };
    var callbacks = function (res) { }
    tsdkClient.init(tsdkAppInfoParam, (res)=>{
        if(res.result == 0) {
            alert("init success!")
        }
    });
    
})(this);