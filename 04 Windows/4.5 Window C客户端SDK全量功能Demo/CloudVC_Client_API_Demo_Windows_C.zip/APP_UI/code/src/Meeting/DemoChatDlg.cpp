// DemoChatDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "DemoChatDlg.h"
#include "afxdialogex.h"


// CDemoChatDlg �Ի���

IMPLEMENT_DYNAMIC(CDemoChatDlg, CDialogEx)

CDemoChatDlg::CDemoChatDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CDemoChatDlg::IDD, pParent)
    , m_szChatMsg(_T("")),m_bIsSending(false)
{

}

CDemoChatDlg::~CDemoChatDlg()
{
}

void CDemoChatDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialogEx::DoDataExchange(pDX);
    DDX_Text(pDX, IDC_EDIT_MSG, m_szChatMsg);
}


BEGIN_MESSAGE_MAP(CDemoChatDlg, CDialogEx)
    ON_BN_CLICKED(IDOK, &CDemoChatDlg::OnBnClickedOk)
END_MESSAGE_MAP()


// CDemoChatDlg ��Ϣ��������


void CDemoChatDlg::OnBnClickedOk()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������
    UpdateData(true);
    CDialogEx::OnOK();
}

CString& CDemoChatDlg::GetChatMsg()
{
    return m_szChatMsg;
}

BOOL CDemoChatDlg::OnInitDialog()
{
    CDialogEx::OnInitDialog();
    ((CEdit*)GetDlgItem(IDC_EDIT_MSG))->SetLimitText(UINT_MAX);
    if(!m_bIsSending)
    {
        UpdateData(false);
        GetDlgItem(IDOK)->SetWindowText(_T("OK"));
        GetDlgItem(IDCANCEL)->ShowWindow(SW_HIDE);
        ((CEdit*)GetDlgItem(IDC_EDIT_MSG))->SetReadOnly();
    }
    return TRUE;  // return TRUE unless you set the focus to a control
}