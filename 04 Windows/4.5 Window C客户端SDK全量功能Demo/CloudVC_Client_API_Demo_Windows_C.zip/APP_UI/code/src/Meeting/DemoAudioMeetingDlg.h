//
//  DemoAudioMeetingDlg.h
//  EC_SDK_DEMO
//
//  Created by EC Open support team.
//  Copyright(C), 2018, Huawei Tech. Co., Ltd. ALL RIGHTS RESERVED.
//

#pragma once
#include "afxcmn.h"
#include "Resource.h"
#include "afxwin.h"
#include "vector"
#include "string"
#include "DemoData.h"
#include "DemoVideoDlg.h"
#include "DemoCallNetInfoDlg.h"
#include "tsdk_common_macro_def.h"


// CDemoAudioMeetingDlg dialog
class CDemoAudioMeetingDlg : public CDialogEx
{
    DECLARE_DYNAMIC(CDemoAudioMeetingDlg)

public:
    CDemoAudioMeetingDlg(CWnd* pParent = NULL);   // ��׼���캯��
    virtual ~CDemoAudioMeetingDlg();

    // Dialog Data
    enum { IDD = IDD_AUDIO_CONF };

protected:
    virtual void DoDataExchange(CDataExchange* pDX);

    DECLARE_MESSAGE_MAP()
protected:
    virtual BOOL OnInitDialog();

public:
    CListCtrl m_listMember;
    CButton m_bt_Mute;
    CButton m_bt_Lock;
    CButton m_bt_Add;
    CButton m_bt_Dtmf;
    CButton m_bt_DataConf;
    CButton m_bt_Handup;
    CButton m_bt_Apply;
    CButton m_bt_Release;
    CButton m_bt_End_Conf;
    CButton m_bt_Leave_Conf;
    CComboBox m_cbxVideoConfMode;
    CEdit m_edit_chairman_pwd;
    CEdit m_edit_subject;
    CButton m_btn_postpone;
    CButton m_btn_apply_speak;
    CButton m_btn_cancel_rollcall;
    bool ischairman;
    bool ischairmanexist;
    bool ispresenter;
    unsigned int m_confID;
    unsigned int m_callID;
    unsigned int m_handle;
    unsigned int m_confType;
    CStatic m_static_subject;
    UINT m_postponeTime;
    bool isNeedPrompting;
    bool isMsgShow;
    bool is_in_roll_calling;
    CButton m_btn_publicMsg;
    CDemoCallNetInfoDlg* m_pNetWorkInfoDlg;
    UINT m_edit_send_data_msgid;
    CButton m_btn_publicData;
    string rollCalledNumber;
    CButton m_btn_wiredProjection;
    CButton m_btn_wirelessProjection;
public:
    void SetCallID(unsigned int callid) { m_callID = callid; };
    unsigned int GetCallID() { return m_callID; };
    void SetConfId(unsigned int confid) { m_confID = confid; };
    void SetConfHandle(unsigned int handle) { m_handle = handle; };
    BOOL FindColum(const CString& cstrKey, int iColnum, int& iFind);
    void GetAttendes(std::vector<CString> &_member);
    void CloseDlg();
    std::string GetUserStatus(TSDK_E_CONF_PARTICIPANT_STATUS status);
    void UpdateAudioConfButtonStatus();
    unsigned int GetConfID(void) { return m_confID; };
private:
    void SendChatMessage(TSDK_E_CONF_CHAT_TYPE chatType, CString szRevicierNum);
    void SendData(TSDK_S_CONF_CUSTOM_DATA_TYPE dataType, CString szRevicierNum, UINT cstrDataMsgid);
public:
    afx_msg void OnBnClickedBtAddMember();
    afx_msg void OnBnClickedBtMute();
    afx_msg void OnBnClickedBtLock();
    afx_msg void OnBnClickedBtHandUp();
    afx_msg void OnBnClickedBtDataconf();
    afx_msg void OnBnClickedBtApplyChairman();
    afx_msg void OnBnClickedBtReleaseChairman();
    afx_msg void OnBnClickedBtDtmf();
    afx_msg void OnBnClickedBtEndConf();
    afx_msg void OnBnClickedBtLeaveConf();
    afx_msg void OnCbnSelchangeComboSetConfMode();
    afx_msg void OnNMRClickMemberList(NMHDR *pNMHDR, LRESULT *pResult);
    afx_msg void OnClickListMemMenuItem(UINT nID);

    afx_msg LRESULT OnConfOperationResult(WPARAM, LPARAM);
    afx_msg LRESULT OnConfSpeakerUpdate(WPARAM, LPARAM);
    afx_msg LRESULT OnConfInfoAndStatusUpdate(WPARAM, LPARAM);
    afx_msg void OnBnClickedBtPostponeConf();
    afx_msg void OnBnClickedBtApplyPresenter();

    afx_msg void OnBnClickedButtonChat();
    afx_msg LRESULT OnReceivedChatMsg(WPARAM, LPARAM);
    afx_msg void OnBnClickedButtonPublicchat();
    afx_msg void OnBnClickedBtApplySpeak();
    afx_msg void OnBnClickedButtonNet();
    afx_msg void OnBnClickedBtCancelRollcall();
    afx_msg LRESULT OnReceivedUserDataMsg(WPARAM, LPARAM);
    afx_msg void OnBnClickedButtonPublicdata();
    afx_msg void CloseNetWorkWindow();
    afx_msg LRESULT OnConfUiPluginClickLeaveConf(WPARAM wparam, LPARAM);
    afx_msg LRESULT OnConfUiPluginClickEndConf(WPARAM wparam, LPARAM);
    afx_msg LRESULT OnConfUiPluginClickStartShare(WPARAM wparam, LPARAM);
    afx_msg LRESULT OnConfUiPluginSetWindowSize(WPARAM wparam, LPARAM);

    afx_msg void OnBnClickedButtonSetSubject();
    afx_msg void OnBnClickedButtonSetWiredprojection();
    afx_msg void OnBnClickedButtonSetWirelessprojection();
};
