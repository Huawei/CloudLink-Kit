// DemoCallNetInfoDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "DemoCallNetInfoDlg.h"
#include "afxdialogex.h"
#include "DemoCommonTools.h"

#define TIMER1 1000
// CDemoCallNetInfoDlg �Ի���

IMPLEMENT_DYNAMIC(CDemoCallNetInfoDlg, CDialogEx)

CDemoCallNetInfoDlg::CDemoCallNetInfoDlg(CWnd* pParent /*=NULL*/, unsigned int CallID)
    : CDialogEx(CDemoCallNetInfoDlg::IDD, pParent)
{
    m_CallID = CallID;
}

CDemoCallNetInfoDlg::~CDemoCallNetInfoDlg()
{
    KillTimer(TIMER1);
}

void CDemoCallNetInfoDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialogEx::DoDataExchange(pDX);
    DDX_Control(pDX, IDC_LIST_AUDIO, m_lstAudioInfo);
    DDX_Control(pDX, IDC_LIST_VIDEO, m_lstVideoInfo);
    DDX_Control(pDX, IDC_LIST_RX_VIDEO, m_lstRxVideo);
}


BEGIN_MESSAGE_MAP(CDemoCallNetInfoDlg, CDialogEx)
    ON_WM_TIMER()
END_MESSAGE_MAP()


// CDemoCallNetInfoDlg ��Ϣ��������


BOOL CDemoCallNetInfoDlg::OnInitDialog()
{
    CDialogEx::OnInitDialog();

    DWORD dwStyle = m_lstAudioInfo.GetExtendedStyle();
    dwStyle |= LVS_EX_GRIDLINES;                //������(LVS_REPORT)
    m_lstAudioInfo.SetExtendedStyle(dwStyle);

    dwStyle = m_lstVideoInfo.GetExtendedStyle();
    dwStyle |= LVS_EX_GRIDLINES;                //������(LVS_REPORT)
    m_lstVideoInfo.SetExtendedStyle(dwStyle);

    m_lstAudioInfo.InsertColumn( 0, _T("״̬"), LVCFMT_LEFT, 100);
    m_lstAudioInfo.InsertColumn( 1, _T("Э��"), LVCFMT_LEFT, 100 );
    m_lstAudioInfo.InsertColumn( 2, _T("����"), LVCFMT_LEFT, 100);
    m_lstAudioInfo.InsertColumn( 3, _T("����"), LVCFMT_LEFT, 100);
    m_lstAudioInfo.InsertColumn( 4, _T("��ʱ"), LVCFMT_LEFT, 100);
    m_lstAudioInfo.InsertColumn( 5, _T("����"), LVCFMT_LEFT, 100);
    m_lstAudioInfo.InsertItem(0, _T("����"));
    m_lstAudioInfo.InsertItem(1, _T("����"));

    m_lstVideoInfo.InsertColumn( 0, _T("״̬"), LVCFMT_LEFT, 80);
    m_lstVideoInfo.InsertColumn( 1, _T("Э��"), LVCFMT_LEFT, 80 );
    m_lstVideoInfo.InsertColumn( 2, _T("����"), LVCFMT_LEFT, 80);
    m_lstVideoInfo.InsertColumn( 3, _T("�ֱ���"), LVCFMT_LEFT, 80);
    m_lstVideoInfo.InsertColumn( 4, _T("֡��"), LVCFMT_LEFT, 80);
    m_lstVideoInfo.InsertColumn( 5, _T("����"), LVCFMT_LEFT, 80);
    m_lstVideoInfo.InsertColumn( 6, _T("��ʱ"), LVCFMT_LEFT, 80);
    m_lstVideoInfo.InsertColumn( 7, _T("����"), LVCFMT_LEFT, 80);
    m_lstVideoInfo.InsertItem(0, _T("����"));

    m_lstRxVideo.InsertColumn( 0, _T("�᳡"), LVCFMT_LEFT, 80);
    m_lstRxVideo.InsertColumn( 1, _T("Э��"), LVCFMT_LEFT, 80 );
    m_lstRxVideo.InsertColumn( 2, _T("����"), LVCFMT_LEFT, 80);
    m_lstRxVideo.InsertColumn( 3, _T("�ֱ���"), LVCFMT_LEFT, 80);
    m_lstRxVideo.InsertColumn( 4, _T("֡��"), LVCFMT_LEFT, 80);
    m_lstRxVideo.InsertColumn( 5, _T("����"), LVCFMT_LEFT, 80);
    m_lstRxVideo.InsertColumn( 6, _T("��ʱ"), LVCFMT_LEFT, 80);
    m_lstRxVideo.InsertColumn( 7, _T("����"), LVCFMT_LEFT, 80);
    m_lstRxVideo.InsertItem(0, _T("Զ��"));

    SetTimer(TIMER1,5000,0);
    return TRUE; 
}

void CDemoCallNetInfoDlg::UpdateNetInfo(TSDK_S_MEDIA_QOS_INFO qos_info)
{
    m_lstAudioInfo.SetItemText(0, 1, CTools::num2CString(qos_info.rt_tx_audio.protocol));
    m_lstAudioInfo.SetItemText(0, 2, CTools::num2CString(qos_info.rt_tx_audio.bit_rate));
    m_lstAudioInfo.SetItemText(0, 3, CTools::num2CString(qos_info.rt_tx_audio.lost_per));
    m_lstAudioInfo.SetItemText(0, 4, CTools::num2CString(qos_info.rt_tx_audio.delay));
    m_lstAudioInfo.SetItemText(0, 5, CTools::num2CString(qos_info.rt_tx_audio.jitter));

    m_lstAudioInfo.SetItemText(1, 1, CTools::num2CString(qos_info.rt_rx_audio.protocol));
    m_lstAudioInfo.SetItemText(1, 2, CTools::num2CString(qos_info.rt_rx_audio.bit_rate));
    m_lstAudioInfo.SetItemText(1, 3, CTools::num2CString(qos_info.rt_rx_audio.lost_per));
    m_lstAudioInfo.SetItemText(1, 4, CTools::num2CString(qos_info.rt_rx_audio.delay));
    m_lstAudioInfo.SetItemText(1, 5, CTools::num2CString(qos_info.rt_rx_audio.jitter));

    //Э��
    m_lstVideoInfo.SetItemText(0, 1, CTools::num2CString(qos_info.rt_tx_main_video.protocol));
    //����
    m_lstVideoInfo.SetItemText(0, 2, CTools::num2CString(qos_info.rt_tx_main_video.bit_rate));
    //�ֱ���
    CString strtxWidthHight;
    strtxWidthHight.Format(_T("%dx%d"),qos_info.rt_tx_main_video.width, qos_info.rt_tx_main_video.height);
    m_lstVideoInfo.SetItemText(0, 3, strtxWidthHight);
    m_lstVideoInfo.SetItemText(0, 4, CTools::num2CString(qos_info.rt_tx_main_video.frame_rate));
    m_lstVideoInfo.SetItemText(0, 5, CTools::num2CString(qos_info.rt_tx_main_video.lost_packets));
    m_lstVideoInfo.SetItemText(0, 6, CTools::num2CString(qos_info.rt_tx_main_video.delay));
    m_lstVideoInfo.SetItemText(0, 7, CTools::num2CString(qos_info.rt_tx_main_video.jitter));

    //������Ƶ����
    //Э��
    m_lstRxVideo.SetItemText(0, 1, CTools::num2CString(qos_info.rt_rx_main_video.protocol));
    //����
    m_lstRxVideo.SetItemText(0, 2, CTools::num2CString(qos_info.rt_rx_main_video.bit_rate));
    //�ֱ���
    CString strrxWidthHight;
    strrxWidthHight.Format(_T("%dx%d"),qos_info.rt_rx_main_video.width, qos_info.rt_rx_main_video.height);
    m_lstRxVideo.SetItemText(0, 3, strrxWidthHight);
    m_lstRxVideo.SetItemText(0, 4, CTools::num2CString(qos_info.rt_rx_main_video.frame_rate));
    m_lstRxVideo.SetItemText(0, 5, CTools::num2CString(qos_info.rt_rx_main_video.lost_packets));
    m_lstRxVideo.SetItemText(0, 6, CTools::num2CString(qos_info.rt_rx_main_video.delay));
    m_lstRxVideo.SetItemText(0, 7, CTools::num2CString(qos_info.rt_rx_main_video.jitter));
}


void CDemoCallNetInfoDlg::OnTimer(UINT_PTR nIDEvent)
{
    // TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ
    switch(nIDEvent)
    {
    case TIMER1:
        { 
            TSDK_S_MEDIA_QOS_INFO qos_info = {0};
            service_get_call_info(m_CallID, &qos_info);
            UpdateNetInfo(qos_info);
            break;
        }
    default:
        break;
    }
    CDialogEx::OnTimer(nIDEvent);
}
