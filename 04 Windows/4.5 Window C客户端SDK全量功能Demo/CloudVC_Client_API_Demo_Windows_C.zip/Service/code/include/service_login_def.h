//
//  service_login_def.h
//  EC_SDK_DEMO
//
//  Created by EC Open support team.
//  Copyright(C), 2018, Huawei Tech. Co., Ltd. ALL RIGHTS RESERVED.
//

#ifndef __SERVICE_LOGIN_DEF_H__
#define __SERVICE_LOGIN_DEF_H__

#include "tsdk_def.h"
#include "tsdk_manager_def.h"

#ifdef __cplusplus
#if __cplusplus
extern "C"{
#endif
#endif /* __cplusplus */

    /**
    * [en]This enum is used to describe environment type.
    * [cn]��¼��������
    */
    typedef enum tagLOGIN_ENV_TYPE
    { 
        LOGIN_ENV_EC = 0,                                                   /**< [en]Indicates the ec enviroment. 
                                                                            [cn]ec �������� */
        LOGIN_ENV_VC,                                                       /**< [en]Indicates the vc enviroment. 
                                                                            [cn]vc �������� */
        LOGIN_ENV_UAP                                                       /**< [en]Indicates the uap enviroment. 
                                                                            [cn]uap �������� */
    } LOGIN_ENV_TYPE;


    /**
    * [en]This enumeration is used to describe the signaling transport mode.
    * [cn]SIP�����ģʽ(��ѡ�����ã������ʼ�����¼ǰ����,��TSDK��ö��TSDK_E_SIP_TRANSPORT_MODE����һ��)
    */
    typedef enum tagSIP_TRANSPORT_MODE
    {
        SIP_TRANSPORT_UDP,                              /**< [en]Indicates UDP
                                                             [cn]UDP */
        SIP_TRANSPORT_TLS,                              /**< [en]Indicates TLS
                                                             [cn]TLS */
        SIP_TRANSPORT_TCP,                              /**< [en]Indicates TCP
                                                             [cn]TCP */
        SIP_TRANSPORT_DEFAULT,                          /**< [en]Indicates the default use public transport mode
                                                             [cn]Ĭ��ʹ�ù��ô��䷽ʽ */
        SIP_TRANSPORT_SVN,                              /**< [en]Indicates SVN
                                                             [cn]SVN */
        SIP_TRANSPORT_BUTT
    } SIP_TRANSPORT_MODE;

    /**
    * [en]This structure is used to describe login parameters.
    * [cn]��¼��Ϣ����
    */
    typedef struct tagSERVICE_S_LOGIN_PARAM
    { 
        TSDK_CHAR user_name[TSDK_D_MAX_ACCOUNT_LEN + 1];                    /**< [en]Indicates the account username. 
                                                                            [cn]�˻��û�������Ȩ����ΪTSDK_E_AUTH_NORMALʱ��д */
        TSDK_CHAR password[TSDK_D_MAX_PASSWORD_LENGTH + 1];                 /**< [en]Indicates the account password. 
                                                                            [cn]�˻����룬��Ȩ����ΪTSDK_E_AUTH_NORMALʱ��д */
        LOGIN_ENV_TYPE env_type;                                            /**< [en]Indicates the service environment type. 
                                                                            [cn]�������� */
        TSDK_CHAR server_addr[TSDK_D_MAX_URL_LENGTH + 1];                   /**< [en]Indicates the server address. 
                                                                            [cn]��������ַ */
        TSDK_UINT16 server_port;                                            /**< [en]Indicates the server port. 
                                                                            [cn]�������˿ں� */
    } SERVICE_S_LOGIN_PARAM;


#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* __SERVICE_LOGIN_DEF_H__ */
